package appcode;

public class SomeTest {

	public int sum(int a, int b) {
		return a + b;
	}
	public String addString(String a, String b) {
		return a+" "+b;
	}
	public int[] getArray() {
		int[] arrayExample= {1,2,3};
		return arrayExample;
	}
}
