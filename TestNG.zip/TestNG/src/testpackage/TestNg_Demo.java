package testpackage;

import org.testng.annotations.Test;

public class TestNg_Demo {
	
	@Test
	public void testMethod() {
		
	}
}
