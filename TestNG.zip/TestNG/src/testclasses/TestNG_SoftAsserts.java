package testclasses;

import org.testng.asserts.SoftAssert;
import org.testng.annotations.Test;

import appcode.SomeTest;

public class TestNG_SoftAsserts {
  @Test
  public void testSum() {
	  	SoftAssert so=new SoftAssert();
		System.out.println("\n test case test sum");
		SomeTest o= new SomeTest();
		int r=o.sum(1,2);
		so.assertEquals(r, 2);
		System.out.println("assert1 done");
		so.assertEquals(r, 3);
		System.out.println("assert2 done");
		so.assertAll();
	}
}
