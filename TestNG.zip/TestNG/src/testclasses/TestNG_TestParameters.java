package testclasses;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNG_TestParameters {
	@BeforeClass
	@Parameters({"browser","platform"})
	public void before(String browser, String platform) {
		System.out.println("parameters--setup");
		System.out.println("1.parameter value from xml file:" +browser);
		System.out.println("2.parameter value from xml file:" +platform);

	}
  @Test
  @Parameters({"response"})
  public void test1(String response) {
	  System.out.println("TestNG_TestParameters--test1");
	  System.out.println("response from xml file"+response);
  }
}
