package testclasses;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
//import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
//import listeners.*;

//@Listeners(CustomListener1.class)
public class Listeners1 {
  @Test
  public void test1() {
	  System.out.println("code in test1");
	  Assert.assertTrue(true);
  }
  @Test
  public void test2() {
	  System.out.println("code in test2");
	  Assert.assertTrue(false);
  }
  @BeforeClass
  public void before() {
	  System.out.println("code in before class");
  }
  @AfterClass
  public void after() {
	  System.out.println("code in after class");
  }
}
