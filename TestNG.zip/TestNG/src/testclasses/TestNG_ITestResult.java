package testclasses;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class TestNG_ITestResult {
	@Test
	public void test1() {
		System.out.println("Running--test1");
		Assert.assertTrue(false);
	}

	@Test
	public void test2() {
		System.out.println("Running--test2");
		Assert.assertTrue(true);
	}

	@AfterMethod
	public void afterMethod(ITestResult testresult) {
		if(testresult.getStatus()==ITestResult.FAILURE) {
			System.out.println("failed:" +testresult.getMethod().getMethodName());
		}
		if(testresult.getStatus()==ITestResult.SUCCESS) {
			System.out.println("successful:" +testresult.getName());
		}
	}
}
