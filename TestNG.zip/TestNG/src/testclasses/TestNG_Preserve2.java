package testclasses;

import org.testng.annotations.Test;

public class TestNG_Preserve2 {
	 @Test
	  public void test1() {
		  System.out.println("preserve2---test1");
	  }
	  @Test
	  public void test2() {
		  System.out.println("preserve2---test2");
	  }
}
