package testclasses;

import org.testng.annotations.Test;

public class Parallel1 {
  @Test
  public void test() throws InterruptedException {
	  System.out.println("parallel1 tests--");
	  Thread.sleep(6000);
	  System.out.println("test method has more steps");
  }
  @Test
  public void test1() throws InterruptedException {
	  System.out.println("parallel1 tests");
	  Thread.sleep(6000);
	  System.out.println("test method has more steps");
  }
}
