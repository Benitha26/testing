package testclasses;

import org.testng.annotations.Test;

public class Parallel2 {
	 @Test
	  public void test() throws InterruptedException {
		  System.out.println("parallel2 tests");
		  Thread.sleep(6000);
		  System.out.println("test method has more steps");
	  }
	  @Test
	  public void test1() throws InterruptedException {
		  System.out.println("parallel2 tests");
		  Thread.sleep(6000);
		  System.out.println("test method has more steps");
	  }
}
