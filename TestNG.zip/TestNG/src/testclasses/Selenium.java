package testclasses;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Selenium {
	String baseURL;
	WebDriver driver;
  @Test
  public void f() {
  }
  @BeforeClass
  @Parameters({"browser"})
  public void before(String bowser) {
	  baseURL="https://testkodeit.teachable.com";
	  if(browser.equalsIgnoreCase("chrome")) {
		  
	  }
	  else if(browser.equalsIgnoreCase("firefox"))
  }
  @AfterClass
  public void after(String driver) {
	  driver.Quit();
  }
}
