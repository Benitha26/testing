package testclasses;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class ReportsAndLogs {
  @Test
  public void test1() {
	  Reporter.log("reportand logs--> test 1",true);
	  //System.out.println("reportand logs--> test 1");
  }
  @Test
  public void test2() {
	  Reporter.log("reportand logs--> test 2",true);
	//  System.out.println("reportand logs--> test 2");
  Assert.assertTrue(false);
  }
  @Test(dependsOnMethods= {"test2"})
  public void test3() {
	  Reporter.log("reportand logs--> test 3",true);
	 // System.out.println("reportand logs--> test 3 ");
  }
  @BeforeMethod
  public void beforeMethod() {
	  Reporter.log("reportsandlogs-->runs before method",true);
	 // System.out.println("reportsandlogs-->this runs before method");

  }

  @AfterMethod
  public void afterMethod() {
	//  System.out.println("reportsandlogs-->this runs after method");
	  Reporter.log("reportsandlogs-->runs after method",true);
  }

  @BeforeClass
  public void beforeClass() {
	  //System.out.println("reportsandlogs-->this runs before class");
	  Reporter.log("reportsandlogs-->runs before class",true);
  }

  @AfterClass
  public void afterClass() {
	//  System.out.println("reportsandlogs-->this runs after class");
Reporter.log("reportsandlogs-->runs after class", true);
  }

}
