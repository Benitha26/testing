package testclasses;

import org.testng.annotations.Test;

public class TestNG_Preserve1 {
  @Test
  public void test1() {
	  System.out.println("preserve1---test1");
  }
  @Test
  public void test2() {
	  System.out.println("preserve1---test2");
  }
}
