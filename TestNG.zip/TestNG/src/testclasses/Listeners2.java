package testclasses;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import listeners.*;

@Listeners(CustomListener2.class)
public class Listeners2 {
  @Test
  public void test1() {
	  System.out.println("code in test method 1");
  }
  @Test
  public void test2() {
	  System.out.println("code in test method 2");
  }
  @BeforeClass
  public void before() {
	  System.out.println("code in before class");
  }
  @AfterClass
  public void after() {
	  System.out.println("code in after class");
  }
}
