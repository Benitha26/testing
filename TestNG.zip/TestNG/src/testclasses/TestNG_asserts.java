package testclasses;

import org.testng.Assert;
import org.testng.annotations.Test;

import appcode.SomeTest;

public class TestNG_asserts {
	@Test
	public void test1() {
		SomeTest o=new SomeTest();
		int res= o.sum(2, 3);
	//	System.out.println("result is"+res);
		System.out.println("\nfirst test case");
		Assert.assertEquals(res, 5);
	}
	@Test
	public void aaaa() {
		System.out.println("\ntest string testcase");
		String expectedString="hello world";
	//	System.out.println("String is " +expectedString);
		SomeTest o=new SomeTest();
		String res=o.addString("hello","world");
		Assert.assertEquals(res, expectedString);
	}
	@Test
	public void test2() {
		System.out.println("\ntest Arrays");
		int[] expectedArray= {1,2,3,4};
		SomeTest o=new SomeTest();
		int[] res=o.getArray();
		Assert.assertEquals(res, expectedArray);
	}
}
