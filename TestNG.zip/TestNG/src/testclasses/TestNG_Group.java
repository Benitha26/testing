package testclasses;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestNG_Group {
	@BeforeClass(alwaysRun=true)
	public void beforeclass() {
		System.out.println("beforeclass");
	}
	@Test(groups = {"cars","suv"})
	public void BMW() {
		System.out.println("bmw");
	}

	@Test(groups= {"bike"})
	public void triump() {
		System.out.println("triump");
	}

	@Test(groups= {"cars","sedon"})
	public void Benz() {
		System.out.println("benz");
	}
	@Test(groups= {"bicycle"})
	public void btwin() {
		System.out.println("btwin");
	}
	@AfterClass(alwaysRun=true)
	public void afterclass() {
		System.out.println("afterclass");
	}
	
}
