package testclasses;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import appcode.SomeTest;

public class TestNG_Dependent {
	SomeTest o;
	
  @Test(dependsOnMethods= {"test2"}, alwaysRun=true)
  public void test1() {
	  System.out.println("test1 running");
	  
  }
  @Test
  public void test2() {
	  System.out.println("test2 running");
	  int r=o.sum(1, 2);
	  Assert.assertEquals(r, 2);
  }
  @Test
  public void test3() {
	  System.out.println("test3 running");
  }
  @Test(dependsOnMethods= {"test1"})
  public void test4() {
	  System.out.println("test4 running");
  }
  @BeforeClass
  public void beforeClass() {
	  o=new SomeTest();
	  System.out.println("before class");
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("after class");
  }

}
