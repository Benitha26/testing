package testclasses;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestNG_EnableTimeout {
  @Test(enabled=false)
  public void t1() {
	  System.out.println("test1");
  }
  @Test(timeOut=100)
  public void t2() throws InterruptedException {
	  System.out.println("test2");
	  Thread.sleep(10);
  }
  @BeforeClass
  public void before() {
	  System.out.println("before class");
  }
  @AfterClass
  public void after() {
	  System.out.println("after class");
  }
}
