package testclasses;

import org.testng.annotations.Test;
import appcode.SomeTest;

public class TestNG_annotaions {
	@Test
	public void test1() {
		SomeTest o=new SomeTest();
		int res= o.sum(2, 3);
		System.out.println("result is"+res);
		System.out.println("first test case");
	}
}
