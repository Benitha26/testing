package testclasses;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class TestNG_TestClass1 {
	@AfterClass
	public void afterclass() {
		System.out.println("TestClass1--this runs once after class");
	}
	@BeforeClass
	public void beforeclass() {
		System.out.println("TestClass1--this runs once before class");
	}
	
	@BeforeMethod
	public void beforeMethod() {
		System.out.println("TestClass1--this runs before method");
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("TestClass1--this runs after method");
	}

	@Test
	public void test1() {
		System.out.println("\n test--TestClass1--test1");
	}
	@Test
	public void test2() {
		System.out.println("\n test--TestClass1--test2");
	}
	
}
