package testclasses;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import listeners.CustomListener2;

@Listeners(CustomListener2.class)
public class ISuiteListener {
  @Test
  public void test1() {
	  System.out.println("ISuiteListerner-->test 1");
  }
  @Test
  public void test2() {
	  System.out.println("ISuiteListerner-->test 2");
  }
  @BeforeClass
  public void before() {
	  System.out.println("ISuiteListener-->before class");
  }
  @AfterClass
  public void after() {
	  System.out.println("ISuiteListener-->after class");
  }
}
