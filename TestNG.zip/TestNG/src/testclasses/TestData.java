package testclasses;

import org.testng.annotations.DataProvider;
//import org.testng.annotations.Test;

public class TestData {
	@DataProvider(name="benny")
	public Object[][] getData() {
		return new Object[][] {
			{"bmw","m3"},
			{"audi","a6"},
			{"benz","a1"}
		};
	} 
 /* @Test(dataProvider="benny")
  public void test123(String i,String i2) {
	  System.out.println("input 1"+i);
	  System.out.println("input 2"+i2);
  }*/
}
