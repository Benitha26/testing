package listeners;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;

public class CustomListeners implements IInvokedMethodListener,ITestListener,ISuiteListener {

	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		// before every method in test class
		System.out.println("beforeInvocation: "+testResult.getTestClass().getName()+"--"+method.getTestMethod().getMethodName());
	}

	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		//  after every method in test class
		System.out.println("afterInvocation: "+testResult.getTestClass().getName()+"--"+method.getTestMethod().getMethodName());
	}
	@Override
	public void onTestStart(ITestResult result) {
		// when test starts
		System.out.println("start--:test name"+result.getName());
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		System.out.println("success--:test name"+result.getName());
	}

	@Override
	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		System.out.println("failed--:test name"+result.getName());
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		System.out.println("skip--:test name"+result.getName());
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		System.out.println("on start--test tag name"+context.getName());
		ITestNGMethod methods[]=context.getAllTestMethods();
		System.out.println("it will be executed in test tag");
		for(ITestNGMethod method:methods) {
			System.out.println(method.getMethodName());
		}
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		System.out.println("on finish--test tag name"+context.getName());
	}

@Override
public void onStart(ISuite suite) {
	// TODO Auto-generated method stub
	System.out.println("on start:before suite starts");
}

@Override
public void onFinish(ISuite suite) {
	// TODO Auto-generated method stub
	System.out.println("on finish: after suite finishes");
}
}
