package listeners;

import org.testng.ISuite;
import org.testng.ISuiteListener;
//import org.testng.annotations.Test;

public class CustomListener3 implements ISuiteListener {
 

@Override
public void onStart(ISuite suite) {
	// TODO Auto-generated method stub
	System.out.println("on start:before suite starts");
}

@Override
public void onFinish(ISuite suite) {
	// TODO Auto-generated method stub
	System.out.println("on finish: after suite finishes");
}
}
